// Function สร้าง Redux Store ---------------------
function createStore(reducer) {
  let currentState
  let currentListener = []

  function getState() {
    return currentState
  }

  function dispatch(action) {
    currentState = reducer(currentState, action)

    currentListener.forEach(listener => {
      listener()
    })
  }

  function subscribe(listener) {
    currentListener.push(listener)

    return function unsubscribe() {
      const index = currentListener.indexOf(listener)
      currentListener.splice(index, 1)
    }
  }

  // ตอนสร้าง store เสร็จ เราจะ dispatch type ชื่อ INIT
  // เพื่อให้ reducer คืนค่า initial state กลับมา
  dispatch({ type: '@@redux/INIT' })

  return {
    getState,
    dispatch,
    subscribe
  }
}

export { createStore }

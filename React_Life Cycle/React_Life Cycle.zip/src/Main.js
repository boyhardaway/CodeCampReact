import React from 'react'
import { Switch, Route } from 'react-router-dom'
import Parent from './pages/Parent'
import Another from './pages/Another'

const Main = () => (
  <Switch>
    <Route path="/" exact render={() => <Parent name="parent 1" />} />
    <Route path="/p" exact render={() => <Parent name="parent 2" />} />
    <Route path="/a" exact render={() => <Another />} />
  </Switch>
)

export default Main

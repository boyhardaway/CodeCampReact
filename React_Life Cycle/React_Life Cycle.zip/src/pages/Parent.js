import React, { Component } from 'react'
import Children from './Children'

class Parent extends Component {
  constructor(props) {
    super(props)
    this.state = { a: 0 }
    console.log(this.props.name + ' constructor')
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    console.log(nextProps.name + ' getDerivedStateFromProps')
    return null
  }

  componentDidMount() {
    console.log(this.props.name + ' componentDidMount')
  }

  shouldComponentUpdate(nextProps, nextState) {
    console.log(this.props.name + ' shouldComponentUpdate')
    return true
  }

  getSnapshotBeforeUpdate(prevProps, prevState) {
    console.log(this.props.name + ' getSnapshotBeforeUpdate')
    return null
  }

  componentDidUpdate(prevProps, prevState, snapshot) {
    console.log(this.props.name + ' componentDidUpdate')
  }

  componentWillUnmount() {
    console.log(this.props.name + ' componentWillUnmount')
  }

  handleClick = () => {
    console.log('----set state----')
    this.setState({ a: this.state.a + 1 })
  }

  render() {
    console.log(this.props.name + ' render')
    return (
      <div>
        <h1>Parent {this.props.name}</h1>
        <button onClick={this.handleClick}>set state</button>
        <Children a={this.state.a} />
      </div>
    )
  }
}

export default Parent

import React, { Component } from 'react'

class Children extends Component {
  state = { a: 1 }
  constructor(props) {
    super(props)
    console.log('children constructor')
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    console.log('children getDerivedStateFromProps')
    return null
  }

  componentDidMount() {
    console.log('children componentDidMount')
  }

  shouldComponentUpdate(nextProps, nextState) {
    console.log('children shouldComponentUpdate')
    return true
  }

  getSnapshotBeforeUpdate(prevProps, prevState) {
    console.log('children getSnapshotBeforeUpdate')
    return null
  }

  componentDidUpdate(prevProps, prevState, snapshot) {
    console.log('children componentDidUpdate')
  }

  componentWillUnmount() {
    console.log('children componentWillUnmount')
  }

  render() {
    console.log('children render')
    return <div>children {this.props.a}</div>
  }
}

export default Children

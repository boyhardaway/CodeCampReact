import React, { Component } from 'react'
class Another extends Component {
  constructor(props) {
    super(props)
    this.state = {}
    console.log('Another constructor')
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    console.log('Another getDerivedStateFromProps')
    return null
  }

  componentDidMount() {
    console.log('Another componentDidMount')
  }

  shouldComponentUpdate(nextProps, nextState) {
    console.log('Another shouldComponentUpdate')
    return true
  }

  getSnapshotBeforeUpdate(prevProps, prevState) {
    console.log('Another getSnapshotBeforeUpdate')
    return null
  }

  componentDidUpdate(prevProps, prevState, snapshot) {
    console.log('Another componentDidUpdate')
  }

  componentWillUnmount() {
    console.log('Another componentWillUnmount')
  }

  render() {
    console.log('Another render')
    return <h1>Another Component</h1>
  }
}

export default Another

import React from 'react'
import { Link } from 'react-router-dom'

const Navbar = () => (
  <ul>
    <li>
      <Link to="/">Parent 1</Link>
    </li>
    <li>
      <Link to="/p">Parent 2</Link>
    </li>
    <li>
      <Link to="/a">Another</Link>
    </li>
  </ul>
)

export default Navbar
